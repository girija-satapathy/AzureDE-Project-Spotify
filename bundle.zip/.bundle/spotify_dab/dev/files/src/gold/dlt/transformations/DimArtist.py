import dlt

@dlt.table
def dimartist_stg():
    df = spark.readStream.table("spotify_catalog.silver.dimartist")
    return df

dlt.create_streaming_table(name="dimartist")

dlt.create_auto_cdc_flow(
  target = "dimartist",
  source = "dimartist_stg",
  keys = ["artist_id"],
  sequence_by = "updated_at",
  system_sequence_by = None, # optional
  ignore_null_updates = False, # optional
  ignore_null_updates_column_list = None, # optional
  ignore_null_updates_except_column_list = None, # optional
  columns_to_update = None, # optional
  apply_as_deletes = None, # optional
  apply_as_truncates = None, # optional
  column_list = None, # optional
  except_column_list = None, # optional
  stored_as_scd_type = "2", # optional
  track_history_column_list = None, # optional
  track_history_except_column_list = None, # optional
  name = None, # optional
  once = False # optional
)